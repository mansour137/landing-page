# Front End Nanodegree Program

Front End Nanodegree Content & Project Resources

## Table of Contents

* [Projects](#projects)
* [Courses](#courses)
* [Style-Guide](#style-guide)

## Projects



## build nav dynamic
1. first select by .querySelectorAll
2. second use "forEach" 
3. third make loop
4. forth build <li> by js
5. fifth build <a> by js 
6. sixth add .addEventListener & scrollIntoView
7. seventhh use .appendChild to create anchor & list

## make section & nav active
1. add .addEventListener to the window
2. use forEach
3. use .getBoundingClintRect();
4. use if statment 
5. use classList add & remove 
6. use forEach inside if 
7. use new if statment
8. use getAttribute 
9. the use classList add & remove


The following is a list of current projects required to complete the Front End Nanodegree.

Note that projects that do not include associated starter code are not linked here.

1. Personal Blog Website
2. [Landing Page](https://github.com/udacity/fend/tree/refresh-2019/projects/landing-page)
3. [Weather Journal App](https://github.com/udacity/fend/tree/refresh-2019/projects/weather-journal-app)
4. [Evaluate A News Article with Natural Language Processing](https://github.com/udacity/fend/tree/refresh-2019/projects/evaluate-news-nlp)
5. Capstone - Travel App

## Courses

The following is a list of the courses associated with the Front End Nanodegree.

* C1 - CSS, Website Layout, Website Components
* C2 - JavaScript & The DOM
* C3 - Web API's and Asynchronous Applications
* C4 - Build Tools and Single Page Web Apps
* C5 - Capstone

## Style-Guide

See below for the Udacity Style Guide used thoroughout the Front End Nanodegree.

* [Nanodegree Style Guide](http://udacity.github.io/frontend-nanodegree-styleguide/)

Laanding page formed by HTML , CSS & JAVASCRIPT :
I add another 2 sections &, build a dynamic navigation 

