/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav


// Add class 'active' to section when near top of viewport


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/


// Build menu 

//dynamic Nav (when add another section , auto add to navigation )
const sections = document.querySelectorAll("section");    //select type
const ulNav = document.querySelector("#navbar__list");    //select id
const fragment = document.createDocumentFragment();    //reduce reflow & repaint

sections.forEach( element => {                      //loop
  const textN = element.getAttribute("data-nav");
  const newLi = document.createElement("li");    //create <li> , {doesn't appear in the nav}
  const newA = document.createElement("a");      //create <a>  , {doesn't appear in the nav}
  newA.addEventListener("click",  ()=> {
    element.scrollIntoView({
      behavior:"smooth"
    })

  })
  newA.textContent = textN
  fragment.appendChild(newA);      //{appear in the nav}
  fragment.appendChild(newLi);     //{appear in the nav}
})

ulNav.appendChild(fragment);


// Scroll to section on link click

// make sections active (dynamic) in the viewport
window.addEventListener('scroll', ()=> {
  sections.forEach(activeSection =>{
    let sectionsLenght = activeSection.getBoundingClientRect();
    if (sectionsLenght.top >=0 && sectionsLenght.top <= 150) {
      sections.forEach(sectionsAll =>{
        //remove active
        sectionsAll.classList.remove('your-active-class');
      });
      //add active
      activeSection.classList.add('your-active-class');
      // add class "rect" to <a> nav will be dynamic 
      // Set sections as active
      const linkSection = document.querySelectorAll('a');
      linkSection.forEach(activeSectionAll => {
        if (activeSection.getAttribute('data-nav') == activeSectionAll.textContent) {
          linkSection.forEach(linkSection =>{
            //remove class "rect" from <a>
            linkSection.classList.remove('rect');
          });
          //add class "rect" to <a>
          activeSectionAll.classList.add('rect');
        }
      });
    }
  });
});




